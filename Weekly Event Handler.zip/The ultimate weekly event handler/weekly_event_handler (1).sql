-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 04, 2020 at 08:54 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `weekly event handler`
--

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(100) NOT NULL,
  `days` varchar(100) NOT NULL,
  `events` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `days`, `events`) VALUES
(32, 'sunday', 'Hiking'),
(33, 'Monday', 'Picnic'),
(34, 'Tuesday', 'Birthday'),
(35, 'Wednesday', 'Interview'),
(36, 'Thursday', 'Seminar'),
(37, 'Friday', 'Presentation'),
(38, 'Saturday', 'Holiday');

-- --------------------------------------------------------

--
-- Table structure for table `friday`
--

CREATE TABLE `friday` (
  `id` int(100) NOT NULL,
  `time` time(6) NOT NULL,
  `task` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `friday`
--

INSERT INTO `friday` (`id`, `time`, `task`) VALUES
(1, '01:00:00.000000', 'Sleep');

-- --------------------------------------------------------

--
-- Table structure for table `monday`
--

CREATE TABLE `monday` (
  `id` int(100) NOT NULL,
  `time` time(6) NOT NULL,
  `task` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `saturday`
--

CREATE TABLE `saturday` (
  `id` int(100) NOT NULL,
  `time` time(6) NOT NULL,
  `task` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `saturday`
--

INSERT INTO `saturday` (`id`, `time`, `task`) VALUES
(1, '01:00:00.000000', 'hello');

-- --------------------------------------------------------

--
-- Table structure for table `sortbydateandtime`
--

CREATE TABLE `sortbydateandtime` (
  `UserId` int(11) DEFAULT NULL,
  `UserName` varchar(100) DEFAULT NULL,
  `IssueDate` date DEFAULT NULL,
  `IssueTime` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `sunday`
--

CREATE TABLE `sunday` (
  `id` int(100) NOT NULL,
  `time` time(6) NOT NULL,
  `task` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sunday`
--

INSERT INTO `sunday` (`id`, `time`, `task`) VALUES
(1, '01:00:00.000000', 'hello'),
(3, '01:00:00.000000', 'a'),
(4, '01:00:00.000000', 'task'),
(5, '01:00:00.000000', 'task'),
(6, '01:00:00.000000', 'task'),
(7, '01:00:00.000000', 'task');

-- --------------------------------------------------------

--
-- Table structure for table `thursday`
--

CREATE TABLE `thursday` (
  `id` int(100) NOT NULL,
  `time` time(6) NOT NULL,
  `task` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `thursday`
--

INSERT INTO `thursday` (`id`, `time`, `task`) VALUES
(1, '01:00:00.000000', 'help1'),
(3, '01:00:00.000000', 'tv show');

-- --------------------------------------------------------

--
-- Table structure for table `tuesday`
--

CREATE TABLE `tuesday` (
  `id` int(100) NOT NULL,
  `time` time(6) NOT NULL,
  `task` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tuesday`
--

INSERT INTO `tuesday` (`id`, `time`, `task`) VALUES
(1, '03:00:00.000000', 'aa'),
(3, '01:00:00.000000', 'hellodiwash');

-- --------------------------------------------------------

--
-- Table structure for table `wednesday`
--

CREATE TABLE `wednesday` (
  `id` int(100) NOT NULL,
  `time` time(6) NOT NULL,
  `task` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `friday`
--
ALTER TABLE `friday`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `monday`
--
ALTER TABLE `monday`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `saturday`
--
ALTER TABLE `saturday`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sunday`
--
ALTER TABLE `sunday`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `thursday`
--
ALTER TABLE `thursday`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tuesday`
--
ALTER TABLE `tuesday`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wednesday`
--
ALTER TABLE `wednesday`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=83;

--
-- AUTO_INCREMENT for table `friday`
--
ALTER TABLE `friday`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `monday`
--
ALTER TABLE `monday`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `saturday`
--
ALTER TABLE `saturday`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `sunday`
--
ALTER TABLE `sunday`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `thursday`
--
ALTER TABLE `thursday`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tuesday`
--
ALTER TABLE `tuesday`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `wednesday`
--
ALTER TABLE `wednesday`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;

DELIMITER $$
--
-- Events
--
CREATE DEFINER=`root`@`localhost` EVENT `dumpevent` ON SCHEDULE EVERY 1 WEEK STARTS '2020-08-16 00:01:00' ENDS '2021-12-31 18:28:14' ON COMPLETION NOT PRESERVE ENABLE DO TRUNCATE TABLE events$$

CREATE DEFINER=`root`@`localhost` EVENT `dumpsunday` ON SCHEDULE EVERY 1 WEEK STARTS '2020-08-09 00:01:00' ON COMPLETION NOT PRESERVE ENABLE DO TRUNCATE TABLE sunday$$

CREATE DEFINER=`root`@`localhost` EVENT `dumpmonday` ON SCHEDULE EVERY 1 WEEK STARTS '2020-08-10 00:01:00' ON COMPLETION NOT PRESERVE ENABLE DO TRUNCATE TABLE monday$$

CREATE DEFINER=`root`@`localhost` EVENT `dumptuesday` ON SCHEDULE EVERY 1 WEEK STARTS '2020-08-11 00:01:00' ON COMPLETION NOT PRESERVE ENABLE DO TRUNCATE TABLE tuesday$$

CREATE DEFINER=`root`@`localhost` EVENT `dumpwednesday` ON SCHEDULE EVERY 1 WEEK STARTS '2020-08-12 00:01:00' ON COMPLETION NOT PRESERVE ENABLE DO TRUNCATE TABLE wednesday$$

CREATE DEFINER=`root`@`localhost` EVENT `dumpthursday` ON SCHEDULE EVERY 1 WEEK STARTS '2020-08-06 21:36:22' ON COMPLETION NOT PRESERVE ENABLE DO TRUNCATE TABLE thursday$$

CREATE DEFINER=`root`@`localhost` EVENT `dumpsaturday` ON SCHEDULE EVERY 1 WEEK STARTS '2020-08-08 00:01:00' ON COMPLETION NOT PRESERVE ENABLE DO TRUNCATE TABLE saturday$$

CREATE DEFINER=`root`@`localhost` EVENT `dumpfriday` ON SCHEDULE EVERY 1 WEEK STARTS '2020-08-07 00:01:00' ON COMPLETION NOT PRESERVE ENABLE DO TRUNCATE TABLE friday$$

DELIMITER ;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
